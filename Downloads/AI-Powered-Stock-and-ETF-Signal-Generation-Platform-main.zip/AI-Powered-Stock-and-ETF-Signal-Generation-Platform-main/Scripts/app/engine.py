# Re-export BacktestEngine from the main backtesting module
from backtesting.engine import BacktestEngine

__all__ = ["BacktestEngine"]
